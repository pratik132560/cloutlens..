import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/clout_ai_service.dart';
import 'summary_page.dart';

class VideoUploadPage extends StatefulWidget {
  const VideoUploadPage({Key? key}) : super(key: key);

  @override
  State<VideoUploadPage> createState() => _VideoUploadPageState();
}

class _VideoUploadPageState extends State<VideoUploadPage> {
  File? _selectedVideo;
  final _picker = ImagePicker();

  Future<void> _pickVideo() async {
    final picked = await _picker.pickVideo(source: ImageSource.gallery);
    if (picked != null) {
      setState(() {
        _selectedVideo = File(picked.path);
      });
    }
  }

  void _analyzeVideo() {
    if (_selectedVideo != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SummaryPage(
            file: _selectedVideo!,
            contentType: "video",
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload Video')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _selectedVideo == null
                ? const Text('No video selected.')
                : const Icon(Icons.videocam, size: 100, color: Colors.deepPurple),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _pickVideo,
              child: const Text('Pick a Video'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _analyzeVideo,
              child: const Text('Analyze with Clout AI'),
            ),
          ],
        ),
      ),
    );
  }
}
