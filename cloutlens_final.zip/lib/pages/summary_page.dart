import 'package:flutter/material.dart';
import 'package:cloutlens/services/clout_ai_service.dart';

class SummaryPage extends StatefulWidget {
  final String description; // text description from upload page

  const SummaryPage({super.key, required this.description});

  @override
  State<SummaryPage> createState() => _SummaryPageState();
}

class _SummaryPageState extends State<SummaryPage> {
  String aiResponse = '';
  bool isLoading = true;

  final TextEditingController _chatController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _getAIResponse();
  }

  Future<void> _getAIResponse() async {
    setState(() => isLoading = true);

    final result = await CloutAIService.analyzeContent(widget.description);

    setState(() {
      aiResponse = result;
      isLoading = false;
    });
  }

  Future<void> _chatWithAI() async {
    final message = _chatController.text.trim();
    if (message.isEmpty) return;

    setState(() {
      aiResponse += "\n\n👤 You: $message";
      _chatController.clear();
    });

    final reply = await CloutAIService.chatWithAI(message);

    setState(() {
      aiResponse += "\n🤖 Clout AI: $reply";
    });

    await Future.delayed(const Duration(milliseconds: 200));
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("CloutLens AI Summary"),
        centerTitle: true,
        backgroundColor: Colors.black87,
      ),
      backgroundColor: Colors.grey[100],
      body: SafeArea(
        child: Column(
          children: [
            // 📄 AI Result Area
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 6,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: isLoading
                    ? const Center(
                        child: CircularProgressIndicator(color: Colors.black87),
                      )
                    : SingleChildScrollView(
                        controller: _scrollController,
                        child: Text(
                          aiResponse.isEmpty
                              ? "No suggestions yet. Try chatting with Clout AI below 👇"
                              : aiResponse,
                          style: const TextStyle(fontSize: 16, height: 1.5),
                        ),
                      ),
              ),
            ),

            // 💬 Chat with AI Section
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _chatController,
                      decoration: const InputDecoration(
                        hintText: "Ask Clout AI anything...",
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: Colors.black87),
                    onPressed: _chatWithAI,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
