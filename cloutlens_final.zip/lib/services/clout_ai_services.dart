import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

class CloutAIService {
  static final String _apiKey = dotenv.env['GEMINI_API_KEY'] ?? '';
  static const String _apiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

  /// Analyze the uploaded photo or video based on text description
  static Future<String> analyzeContent(String description) async {
    if (_apiKey.isEmpty) {
      return 'Error: API key not found. Make sure your .env file is loaded.';
    }

    try {
      final response = await http.post(
        Uri.parse("$_apiUrl?key=$_apiKey"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {
                  "text":
                      "Analyze this media description and give creative tips for improvement: $description"
                }
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final output = data['candidates'][0]['content']['parts'][0]['text'];
        return output;
      } else {
        return 'Error: ${response.statusCode} ${response.reasonPhrase}';
      }
    } catch (e) {
      return 'An error occurred: $e';
    }
  }

  /// (Optional) Chat-like interaction with Clout AI
  static Future<String> chatWithAI(String userMessage) async {
    if (_apiKey.isEmpty) {
      return 'Error: API key not found. Make sure your .env file is loaded.';
    }

    try {
      final response = await http.post(
        Uri.parse("$_apiUrl?key=$_apiKey"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": "You are CloutLens AI. $userMessage"}
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final output = data['candidates'][0]['content']['parts'][0]['text'];
        return output;
      } else {
        return 'Error: ${response.statusCode} ${response.reasonPhrase}';
      }
    } catch (e) {
      return 'An error occurred: $e';
    }
  }
}
