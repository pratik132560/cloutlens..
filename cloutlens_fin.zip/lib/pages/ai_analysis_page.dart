import 'dart:async';
import 'package:flutter/material.dart';

class AiAnalysisPage extends StatefulWidget {
  final String mediaPath;
  final bool isVideo;
  const AiAnalysisPage({required this.mediaPath, required this.isVideo, super.key});

  @override
  State<AiAnalysisPage> createState() => _AiAnalysisPageState();
}

class _AiAnalysisPageState extends State<AiAnalysisPage> {
  final List<Map<String,String>> messages = []; // {role: 'ai'/'user', text: '...'}
  bool loading = true;
  final TextEditingController _ctrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    simulateInitialAi();
  }

  Future<void> simulateInitialAi() async {
    setState(() { loading = true; });
    await Future.delayed(const Duration(seconds: 2));
    messages.add({
      'role': 'ai',
      'text': "Hey creator! 👋 I analyzed your ${widget.isVideo ? 'video' : 'photo'}. "
              "Quick tips: try a slightly higher camera angle and add a warm light from the left. "
              "If you'd like, ask me to create a title/caption or hashtag list."
    });
    setState(() { loading = false; });
  }

  void sendUser(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      messages.add({'role':'user','text':text});
      _ctrl.clear();
      loading = true;
    });
    // simulate AI reply
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        messages.add({'role':'ai','text': "Nice question! Here's a suggestion based on that: Try using a 3/4 angle and increase exposure by +0.3. For captions, try: \"Light, focus, story.\""});
        loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Clout AI"), backgroundColor: Colors.transparent, elevation: 0),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF9B5DE5), Color(0xFFF15BB5)]),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: Container(
                  margin: const EdgeInsets.all(12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
                  child: ListView.builder(
                    itemCount: messages.length + (loading ? 1 : 0),
                    itemBuilder: (context, index) {
                      if (index >= messages.length) {
                        return const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Text("Clout AI is typing...", style: TextStyle(color: Colors.white70)),
                        );
                      }
                      final m = messages[index];
                      final isAi = m['role'] == 'ai';
                      return Container(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        alignment: isAi ? Alignment.centerLeft : Alignment.centerRight,
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                          decoration: BoxDecoration(
                            color: isAi ? Colors.white : Colors.deepPurpleAccent,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(m['text'] ?? '', style: TextStyle(color: isAi ? Colors.black : Colors.white)),
                        ),
                      );
                    },
                  ),
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _ctrl,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: "Ask Clout AI something...",
                            hintStyle: TextStyle(color: Colors.white54),
                            filled: true,
                            fillColor: Colors.white10,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () => sendUser(_ctrl.text),
                        child: const Icon(Icons.send),
                        style: ElevatedButton.styleFrom(shape: const CircleBorder(), padding: const EdgeInsets.all(14)),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
